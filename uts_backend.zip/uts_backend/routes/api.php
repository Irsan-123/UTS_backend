<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PatientsController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


Route::apiResource('patients', PatientsController::class);
Route::get('/patients/status/{status}', [PatientsController::class, 'status']);

Route::get('/name', [PatientsController::class, 'SearchName']);
Route::get('/positive', [PatientsController::class, 'SearchPositive']);
Route::get('/death', [PatientsController::class, 'SearchDeath']);
Route::get('/recovery', [PatientsController::class, 'SearchRecovery']);